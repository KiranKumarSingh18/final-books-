package com.kks.Project.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.kks.Project.entity.Cart;
import com.kks.Project.entity.Customer;

public interface CartRepo extends JpaRepository<Cart, Integer>
{
	
	List<Cart> findByCustomerId( Customer customerId);
	
	@Procedure("increaseCartQuantity")
	void increaseQuantity(
			@Param("cartId") int cartId,
			@Param("bookId") int bookId);
	
	@Procedure("decreaseCartQuantity")
	void decreaseQuantity(
			@Param("cartId") int cartId,
			@Param("bookId") int bookId);

}
