package com.kks.Project.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.kks.Project.entity.Payment;

public interface PaymentRepo extends JpaRepository<Payment, Integer>{

		@Procedure("makePayment")
		void makePayment(
				@Param("customerId") int customerId,
				@Param("ammount") double amount,
				@Param("couponCode") String couponCode);
		
		@Procedure("get_payment")
		Optional<Payment> getPayment(
				@Param("customerId") int customerId);
}
