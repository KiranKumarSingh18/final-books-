package com.kks.Project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.Project.entity.Admin;
import com.kks.Project.entity.Customer;

public interface AdminRepo extends JpaRepository<Admin, Integer>{
	Admin findAdminIdByEmailAndPassword(String email, String password);
}
