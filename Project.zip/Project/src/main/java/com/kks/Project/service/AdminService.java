package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Admin;
import com.kks.Project.repository.AdminRepo;
@Service
public class AdminService {
	@Autowired
	private AdminRepo adminRepo;

	@Transactional(readOnly=true)
	public List<Admin> getAllAdmins()
	{
		return adminRepo.findAll();
	}
	
	@Transactional(readOnly=true)
	public Admin getAdminByAdminId(int adminId)
	{
		Optional<Admin> ot = adminRepo.findById(adminId);
		if(ot.isPresent())
			return ot.get();
		return new Admin();
	}
	
	@Transactional
	public boolean insertOrModifyAdmin(Admin admin)
	{
		if(adminRepo.save(admin) == null)
			return false;
			return true;
	}
	
	@Transactional
	public boolean deleteAdminByAdminId(int adminId)
	{
		long count = adminRepo.count();
		adminRepo.deleteById(adminId);
		if(count > adminRepo.count())
			return true;
		return false;
	}
	
	@Transactional
	public Integer countOfAdmin(String email,String password) {
		Admin a = adminRepo.findAdminIdByEmailAndPassword(email, password);
		if(a != null) {
			return a.getAdminId();
		}
		else
			return null;
	}
}
