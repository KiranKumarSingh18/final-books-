package com.kks.Project.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.kks.Project.entity.Admin;
import com.kks.Project.entity.PopularBooks;
import com.kks.Project.service.AdminService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@CrossOrigin(origins = {"http://localhost:4200"},allowCredentials = "true")
@RestController
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	@GetMapping
	public ResponseEntity<List<Admin>> getAllAdmins()
	{
		List<Admin> blist = adminService.getAllAdmins();
		if(blist.size() != 0)
			return new ResponseEntity<List<Admin>>(blist,HttpStatus.OK);
		return new ResponseEntity<List<Admin>>(blist,HttpStatus.NOT_FOUND);
	}
	
	@GetMapping(value="/{adminId}", produces="application/json")
	public ResponseEntity<Admin> getAdminByAdminId(@PathVariable int adminId)
	{
		Admin a = adminService.getAdminByAdminId(adminId);
		if(a!=null)
			return new ResponseEntity<Admin>(a, HttpStatus.OK);
		return new ResponseEntity<Admin>(a,HttpStatus.NOT_FOUND);
	}
	
	@PostMapping(value="/", consumes="application/json")
	public HttpStatus insertOrModifyAdmin(@RequestBody Admin admin)
	{
		adminService.insertOrModifyAdmin(admin);
		return HttpStatus.OK;
	}
	
	@PutMapping(value="/", consumes="application/json")
	public HttpStatus modifyAdmin(@RequestBody Admin admin)
	{
		adminService.insertOrModifyAdmin(admin);
		return HttpStatus.OK;
	}
	
	@DeleteMapping("/{adminId}")
	public HttpStatus deleteadmin(@PathVariable int adminId)
	{
		if(adminService.deleteAdminByAdminId(adminId))
			return HttpStatus.OK;
		return HttpStatus.NOT_FOUND;
	}
	
	@PostMapping(value="/login",consumes="application/json")
	public boolean countOfValidAdmin(@RequestBody Admin admin,HttpServletRequest request) {
		Integer id = adminService.countOfAdmin(admin.getEmail(),admin.getPassword());
		if( id != null ) {
			 HttpSession session = request.getSession(true);
	            session.setAttribute("id", id);
	            System.out.println(session.getAttribute("id"));
		}
		return id != null;
	}

	@PostMapping(value="/signup", consumes="application/json")
	public HttpStatus insertAdmin(@RequestBody Admin admin)
	{
		adminService.insertOrModifyAdmin(admin);
		return HttpStatus.OK;
	}

	 @GetMapping("/logout")
	 public String logout(HttpSession session) {
//	     HttpSession session = request.getSession(false); // Get the existing session if it exists
	     if (session.getAttribute("id") != null) {
	        session.invalidate(); // Invalidate (destroy) the session
	     }
	     System.out.println(session.getAttribute("id"));
	     return "redirect:/login"; // Redirect to the login page or any other appropriate URL
	 }
	 
	 @GetMapping("/popularbooks")
	 public List<PopularBooks> getPopularBooks()
	 {
		 return adminService.getPopularBooks();
	 }
}
