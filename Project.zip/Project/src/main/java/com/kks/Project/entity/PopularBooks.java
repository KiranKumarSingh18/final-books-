package com.kks.Project.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class PopularBooks 
{
	@Id
	@Column(name="p_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int popularId;
	
	@ManyToOne()
	@JoinColumn(name="book_id")
	private Book bookId;
	
	private int quantity;
	
	@Column(name="total_spent")
	private double totalSpent;
	
	public PopularBooks () {}

	public PopularBooks(int popularId, Book bookId, int quantity, double totalSpent) 
	{
		this.popularId = popularId;
		this.bookId = bookId;
		this.quantity = quantity;
		this.totalSpent = totalSpent;
	}

	public int getPopularId() {
		return popularId;
	}

	public void setPopularId(int popularId) {
		this.popularId = popularId;
	}

	public Book getBookId() {
		return bookId;
	}

	public void setBookId(Book bookId) {
		this.bookId = bookId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalSpent() {
		return totalSpent;
	}

	public void setTotalSpent(double totalSpent) {
		this.totalSpent = totalSpent;
	}
}
