package com.kks.Project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.Project.entity.PopularBooks;

public interface PopularBooksRepo extends JpaRepository<PopularBooks, Integer>
{

}
